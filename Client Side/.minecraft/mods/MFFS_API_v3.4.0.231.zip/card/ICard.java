package mffs.api.card;

public interface ICard
{

}
