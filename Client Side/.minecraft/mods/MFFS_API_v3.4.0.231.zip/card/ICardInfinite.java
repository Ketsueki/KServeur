package mffs.api.card;

public interface ICardInfinite
{

}
