package icbm.api;

/** Types of missile launchers
 * 
 * @author Calclavia */
public enum LauncherType
{
    TRADITIONAL,
    CRUISE
}